angular.module('app.routes', ['ionicUIRouter'])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('tabsController.timer', {
    url: '/timer',
    views: {
      'tab4': {
        templateUrl: 'templates/timer.html',
        controller: 'timerCtrl'
      }
    }
  })

  .state('ChooseTheme', {
    url: '/choosetheme',
    templateUrl: 'templates/ChooseTheme.html',
    controller: 'ChooseThemeCtrl'
  })

  .state('tabsController.studyTechniques', {
    url: '/studytechniques',
    views: {
      'tab4': {
        templateUrl: 'templates/studyTechniques.html',
        controller: 'studyTechniquesCtrl'
      }
    }
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.share'
      2) Using $state.go programatically:
        $state.go('tabsController.share');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab7/share
      /page1/tab5/share
  */
  .state('tabsController.share', {
    url: '/share',
    views: {
      'tab7': {
        templateUrl: 'templates/share.html',
        controller: 'shareCtrl'
      },
      'tab5': {
        templateUrl: 'templates/share.html',
        controller: 'shareCtrl'
      }
    }
  })

  .state('tabsController.setNewTimer', {
    url: '/setnewtimer',
    views: {
      'tab4': {
        templateUrl: 'templates/setNewTimer.html',
        controller: 'setNewTimerCtrl'
      }
    }
  })

  .state('tabsController.viewProductivity', {
    url: '/viewproductivity',
    views: {
      'tab4': {
        templateUrl: 'templates/viewProductivity.html',
        controller: 'viewProductivityCtrl'
      }
    }
  })

  .state('tabsController.music', {
    url: '/music2',
    views: {
      'tab5': {
        templateUrl: 'templates/music.html',
        controller: 'musicCtrl'
      }
    }
  })

  .state('tabsController.music2', {
    url: '/music3',
    views: {
      'tab5': {
        templateUrl: 'templates/music2.html',
        controller: 'music2Ctrl'
      }
    }
  })

  .state('tabsController.music3', {
    url: '/music',
    views: {
      'tab5': {
        templateUrl: 'templates/music3.html',
        controller: 'music3Ctrl'
      }
    }
  })

  .state('tabsController.schedule', {
    url: '/schedule',
    views: {
      'tab6': {
        templateUrl: 'templates/schedule.html',
        controller: 'scheduleCtrl'
      }
    }
  })

  .state('tabsController.schedule2', {
    url: '/schedule2',
    views: {
      'tab6': {
        templateUrl: 'templates/schedule2.html',
        controller: 'schedule2Ctrl'
      }
    }
  })

  .state('tabsController.downloadSchedule', {
    url: '/downloadschedule',
    views: {
      'tab6': {
        templateUrl: 'templates/downloadSchedule.html',
        controller: 'downloadScheduleCtrl'
      }
    }
  })

  .state('tabsController.exisitingSchedules', {
    url: '/exisitingschedules',
    views: {
      'tab6': {
        templateUrl: 'templates/exisitingSchedules.html',
        controller: 'exisitingSchedulesCtrl'
      }
    }
  })

  .state('tabsController.createNewSchedule', {
    url: '/createnewschedule',
    views: {
      'tab6': {
        templateUrl: 'templates/createNewSchedule.html',
        controller: 'createNewScheduleCtrl'
      }
    }
  })

  .state('settings', {
    url: '/settings',
    templateUrl: 'templates/settings.html',
    controller: 'settingsCtrl'
  })

  .state('myProfile', {
    url: '/myprofile',
    templateUrl: 'templates/myProfile.html',
    controller: 'myProfileCtrl'
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.reminders'
      2) Using $state.go programatically:
        $state.go('tabsController.reminders');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab1/reminders
      /page1/tab4/reminders
  */
  .state('tabsController.reminders', {
    url: '/reminders',
    views: {
      'tab1': {
        templateUrl: 'templates/reminders.html',
        controller: 'remindersCtrl'
      },
      'tab4': {
        templateUrl: 'templates/reminders.html',
        controller: 'remindersCtrl'
      }
    }
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.editYourReminders'
      2) Using $state.go programatically:
        $state.go('tabsController.editYourReminders');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab1/edityourreminders
      /page1/tab4/edityourreminders
  */
  .state('tabsController.editYourReminders', {
    url: '/edityourreminders',
    views: {
      'tab1': {
        templateUrl: 'templates/editYourReminders.html',
        controller: 'editYourRemindersCtrl'
      },
      'tab4': {
        templateUrl: 'templates/editYourReminders.html',
        controller: 'editYourRemindersCtrl'
      }
    }
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.noReminders'
      2) Using $state.go programatically:
        $state.go('tabsController.noReminders');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab1/noreminders
      /page1/tab4/noreminders
  */
  .state('tabsController.noReminders', {
    url: '/noreminders',
    views: {
      'tab1': {
        templateUrl: 'templates/noReminders.html',
        controller: 'noRemindersCtrl'
      },
      'tab4': {
        templateUrl: 'templates/noReminders.html',
        controller: 'noRemindersCtrl'
      }
    }
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.newReminder'
      2) Using $state.go programatically:
        $state.go('tabsController.newReminder');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab1/newreminder
      /page1/tab4/newreminder
  */
  .state('tabsController.newReminder', {
    url: '/newreminder',
    views: {
      'tab1': {
        templateUrl: 'templates/newReminder.html',
        controller: 'newReminderCtrl'
      },
      'tab4': {
        templateUrl: 'templates/newReminder.html',
        controller: 'newReminderCtrl'
      }
    }
  })

  .state('aboutUs', {
    url: '/aboutus',
    templateUrl: 'templates/aboutUs.html',
    controller: 'aboutUsCtrl'
  })

  .state('tabsController', {
    url: '/page1',
    templateUrl: 'templates/tabsController.html',
    abstract:true
  })

  .state('tabsController.favorites', {
    url: '/favorites',
    views: {
      'tab7': {
        templateUrl: 'templates/favorites.html',
        controller: 'favoritesCtrl'
      }
    }
  })

  .state('intro', {
    url: '/intro',
    templateUrl: 'templates/intro.html',
    controller: 'introCtrl'
  })

  .state('tabsController.home', {
    url: '/home',
    views: {
      'tab7': {
        templateUrl: 'templates/home.html',
        controller: 'homeCtrl'
      }
    }
  })

  .state('login', {
    url: '/login',
    templateUrl: 'templates/login.html',
    controller: 'loginCtrl'
  })

  .state('sortierRegistration', {
    url: '/sortierregistration',
    templateUrl: 'templates/sortierRegistration.html',
    controller: 'sortierRegistrationCtrl'
  })

$urlRouterProvider.otherwise('/login')


});